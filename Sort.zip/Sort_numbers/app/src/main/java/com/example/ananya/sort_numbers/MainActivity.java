package com.example.ananya.sort_numbers;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
Button b1;
EditText ed1;
TextView res;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.button);
        res=(TextView)findViewById(R.id.textView);
        ed1=(EditText) findViewById(R.id.editText);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String res1=ed1.getText().toString();
                String num[]=res1.split(",");
                int[] answer =sort(num);
                for(int k=0;k<answer.length;k++)
                {
                    res.setText(res.getText().toString()+' '+Integer.toString(answer[k]));
                }

            }
        });
    }
    public int[] sort(String num[])
    {
        int temp;
        int d[]=new int[num.length];
        for(int k=0;k<num.length;k++)
        {
            d[k]=Integer.parseInt(num[k]);
        }
        for(int i=0;i<d.length-1;i++)
        {
            for(int j=i+1;j<d.length;j++)
            {
                if(d[i]>d[j])
                {
                temp=d[i];
                d[i]=d[j];
                d[j]=temp;
                }

            }
        }

        return d;
    }
}
