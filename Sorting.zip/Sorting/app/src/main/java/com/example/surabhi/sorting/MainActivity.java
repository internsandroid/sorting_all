package com.example.surabhi.sorting;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Spannable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
Button button;
EditText edit;
TextView text;
int j,k,l,num[],temp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = (Button) findViewById(R.id.button);
        edit = (EditText) findViewById(R.id.edit);
        text = (TextView) findViewById(R.id.text);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bubblesort();
            }
        });
    }
        public  void bubblesort()
        {
            Spannable sp= edit.getText();

             num=new int[sp.length()];
            for( j=0;j<sp.length();j++)
            {
                int h=Integer.parseInt(""+sp.charAt(j));
                num[j]=h;
            }
            for( k=0;k<num.length;k++)
            {
                for(l=k+1;l<num.length;l++)
                {
                    if(num[k]>num[l])
                    {
                        temp=num[k];
                        num[k]=num[l];
                        num[l]=temp;
                    }
                }

            }
           String sort="";
            for(int p=0;p<num.length;p++)
            {
                sort += num[p] + "";
            }
            text.setText(sort);
        }



}
