package com.example.rishali.myapplication2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
Button b1;
EditText edit;
TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button);
        edit=findViewById(R.id.editText);
        text=findViewById(R.id.textView);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a=edit.getText().toString();
                String []str=a.split(",");
                int []b=new int[str.length];
                for(int i=0;i<b.length;i++){
                    b[i]=Integer.parseInt(str[i]);
                }
                for(int i=0;i<b.length;i++){
                    for(int j=i+1;j<b.length;j++){
                        if(b[i]>b[j]){
                            int temp=b[i];
                            b[i]=b[j];
                            b[j]=temp;
                        }
                    }
                }
                for(int i=0;i<b.length;i++) {
                    text.setText(String.valueOf(text.getText().toString()+b[i])+",");
                }
            }
        });

    }
}
