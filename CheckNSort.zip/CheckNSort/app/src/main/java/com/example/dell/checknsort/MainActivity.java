package com.example.dell.checknsort;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText et;
    TextView txt;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = (Button) findViewById(R.id.btn);
        et = (EditText) findViewById(R.id.et);
        txt = (TextView) findViewById(R.id.txt);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a, b, temp;
                int flag = 0;
                String str = et.getText().toString();
                String[] items = str.split(",");
                txt.setText(" ");
                for (int i = 0; i < items.length; i++) {
                    for (int j = i + 1; j < items.length; j++) {
                        try {
                            a = Integer.parseInt(items[i]);
                            b = Integer.parseInt(items[j]);
                            if (a > b) {
                                temp = a;
                                a = b;
                                b = temp;
                                items[i] = Integer.toString(a);
                                items[j] = Integer.toString(b);
                            }
                        } catch (NumberFormatException e) {
                            et.setError("Enter valid inputs");
                            flag = 1;
                        }
                    }
                }
                if (flag == 0) {
                    for (int i = 0; i < items.length; i++) {
                        if (i < items.length - 1) {
                            txt.setText(txt.getText() + items[i] + " , ");
                        }
                        if (i == items.length - 1) {
                            txt.setText(txt.getText() + items[i]);
                        }
                    }
                }
            }
        });

    }
}
