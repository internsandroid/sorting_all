package com.example.fathima.myapplication1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    Button button;
    EditText edit;
    TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=(Button)findViewById(R.id.button);
        edit=(EditText)findViewById(R.id.editText);
        text=(TextView)findViewById(R.id.textView);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = edit.getText().toString();
                String num[]=str.split(",");
                int[] answer=sort(num);
                //String res=answer.toString();
                for(int k=0;k<answer.length;k++)
                {
                    text.setText(text.getText().toString()+' '+Integer.toString(answer[k]));
                }

            }
        });
    }
    public int[] sort(String[] num)
    {
        int temp;
        int d[]=new int[num.length];
        for(int k=0;k<num.length;k++)
        {
            d[k]=Integer.parseInt(num[k]);
        }
        for(int i=0;i<d.length-1;i++)
        {
            for(int j=i+1;j<d.length;j++)
            {
                if(d[i]>d[j])
                {
                    temp=d[i];
                    d[i]=d[j];
                    d[j]=temp;
                }
            }
        }
        return d;
    }
}
