package com.example.madhusha.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
Button b;
EditText edit;
TextView t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=(Button)findViewById(R.id.button);
        edit=(EditText)findViewById(R.id.editText);
        t=(TextView)findViewById(R.id.textView);

      b.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              String[] a=edit.getText().toString().split(",");
              int b[] = new int[a.length];
              for(int i=0;i<a.length;i++)
              {
                  b[i]=Integer.parseInt(a[i]);

              }

              for(int i=0;i<b.length;i++)
              {
                  for(int j=i+1;j<b.length;j++){
                  if(b[i]>b[j]) {
                      int c = b[i];
                      b[i] = b[j];
                      b[j] = c;

                  }
                  }
              }
              for(int k=0;k<b.length;k++) {

                  t.setText(String.valueOf(t.getText().toString()+b[k])+",");
              }
          }
      });

    }
}
