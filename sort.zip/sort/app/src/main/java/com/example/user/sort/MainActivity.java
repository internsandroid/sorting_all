package com.example.user.sort;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Spannable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText e1;
    TextView t1;
    Button b1;
    int i, j, num[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1 = (EditText)findViewById(R.id.editText);
        t1 = (TextView)findViewById(R.id.text);
        b1 = (Button)findViewById(R.id.button);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BubbleSort();

            }
        });


    }

    public void BubbleSort() {
        Spannable spn = e1.getText();

        num = new int[spn.length()];
        int count = 0;
        for (int i = 0; i < spn.length(); i++) {
            if ((spn.charAt(i) + "").matches(".*\\d.*")) {

                num[i] = Integer.parseInt("" + spn.charAt(i));
                count++;
            }
        }

        int temp = 0;
        for (i = 0; i < num.length - 1; i++) {
            for (j = 0; j < num.length - i-1; j++) {
                if (num[j] > num[j + 1]) {
                    temp = num[j];
                    num[j] = num[j + 1];
                    num[j + 1] = temp;
                }
            }
        }

        String result = "";
        for (int i = 0; i < num.length; i++) {
            result += num[i];
        }
        t1.setText(result);

    }
}


