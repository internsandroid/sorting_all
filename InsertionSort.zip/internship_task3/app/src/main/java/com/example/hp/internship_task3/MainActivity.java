package com.example.hp.internship_task3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btn;
    EditText edit;
    TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = (Button) findViewById(R.id.btn);
        edit = (EditText) findViewById(R.id.edit);
        text = (TextView) findViewById(R.id.text);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String color = edit.getText().toString();
                String[] a = color.split(",");
                text.setText(null);

                Integer[] intvalues = new Integer[a.length];
                for (int i = 0; i < a.length; i++) {
                    intvalues[i] = Integer.parseInt(a[i].trim());
                }
                for (int i = 1; i < intvalues.length; ++i) {
                    int key = intvalues[i];
                    int j = i - 1;
                    while (j >= 0 && intvalues[j] > key) {
                        intvalues[j + 1] = intvalues[j];
                        j = j - 1;
                    }
                    intvalues[j + 1] = key;
                }
                for (int i = 0; i < intvalues.length;i++) {
                     if(i<intvalues.length-1) {
                         text.setText(text.getText() + Integer.toString(intvalues[i]) + " , ");
                     }
                    if(i==intvalues.length-1) {
                        text.setText(text.getText() + Integer.toString(intvalues[i]) );

                    }

                }

            }
        });
    }
}
